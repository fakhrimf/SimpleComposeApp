package com.fakhrimf.simplecomposeapp.utils

// Intents
const val WEAPON_DETAIL = "detail_weapon_yeye"